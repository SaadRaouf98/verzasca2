export enum StatisticsOpenStatus {
  Opened = 1,
  Closed = 2,
}
