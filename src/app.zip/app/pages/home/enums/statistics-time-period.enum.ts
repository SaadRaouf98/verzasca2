export enum StatisticsTimePeriod {
  Daily = 1,
  Monthly = 2,
  Annual = 3,
}
