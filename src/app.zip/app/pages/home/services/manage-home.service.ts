import { Injectable } from '@angular/core';
import { MeetingsService } from '@core/services/backend-services/meetings.service';
import { NewsPostsService } from '@core/services/backend-services/news-posts.service';
import { StatisticsService } from '@core/services/backend-services/statistics.service';

@Injectable({
  providedIn: 'root',
})
export class ManageHomeService {
  constructor(
    public meetingsService: MeetingsService,
    public latestNewsService: NewsPostsService,
    public statisticsService: StatisticsService
  ) {}
}
