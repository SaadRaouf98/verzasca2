import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class I18nService {
  language = 'ar'; // Default language
}
