import { ViewFileModalComponent } from '@shared/components/view-file-modal/view-file-modal.component';

export const myEnum = {
  ViewFileModalComponent: {
    id: 1,
    obj: ViewFileModalComponent,
  },
};
