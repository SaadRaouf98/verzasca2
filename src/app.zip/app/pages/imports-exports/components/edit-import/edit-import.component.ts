import { RequestStatus } from './../../../../core/enums/request-status.enum';
import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import {
  AbstractControl,
  FormArray,
  FormControl,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { LanguageService } from '@core/services/language.service';
import { TranslateService } from '@ngx-translate/core';
import { ManageImportsExportsService } from '@pages/imports-exports/services/manage-imports-exports.service';
import * as moment from 'moment';
import { CurrencyPipe, Location } from '@angular/common';
import {
  compareFn,
  formatDateToYYYYMMDD,
  isTouched,
} from '@shared/helpers/helpers';
import { Classification } from '@core/models/classification.model';
import { Observable, of, tap } from 'rxjs';
import { Priority } from '@core/models/priority.model';

import {
  Attachment,
  RequestDetails,
  UpdateRequestCommand,
} from '@core/models/request.model';
import { ToastrService } from 'ngx-toastr';
import { ModalStatusCode } from '@shared/enums/modal-status-code.enum';
import { SuccessModalComponent } from '@shared/components/success-modal/success-modal.component';
import { EditFileWithBarcodeModalComponent } from '@pages/imports-exports/modals/edit-file-with-barcode-modal/edit-file-with-barcode-modal.component';
import { NewHijriCalendarComponent } from '@shared/components/new-hijri-calendar/new-hijri-calendar.component';
import { OrganizationUnit } from '@core/models/organization-unit.model';
import { OrganizationUnitType } from '@core/enums/organization-unit-type.enum';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { ClassificationLevel } from '@core/enums/classification-level.enum';
import { UsersService } from '@core/services/backend-services/users.service';

@Component({
  selector: 'app-edit-import',
  templateUrl: './edit-import.component.html',
  styleUrls: ['./edit-import.component.scss'],
  /*   providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ], */
})
export class EditImportComponent {
  get gregorianTodayDate(): Date {
    return new Date(
      this.gregorianToday.year,
      this.gregorianToday.month - 1,
      this.gregorianToday.day
    );
  }
  lang: string = 'ar';
  form!: FormGroup;
  requestId: string = '';
  allowEditContainer: boolean = true;

  physicalHijriDateCalendarInput!: string;
  deliveryHijriDateCalendarInput!: string;
  availabilityHijriDateCalendarInput!: string;

  classificationsList: Classification[] = [];

  prioritiesList: Priority[] = [];
  containersList$: Observable<{
    data: any[];
    totalCount: number;
  }> = new Observable();
  foundationsList$: Observable<{
    data: { id: string; title: string; titleEn: string }[];
    totalCount: number;
  }> = new Observable();
  subFoundationsList$: Observable<{
    data: { id: string; title: string; titleEn: string }[];
    totalCount: number;
  }> = new Observable();
  concernedFoundationsList: { id: string; title: string; titleEn: string }[] =
    [];
  requestTypesList$: Observable<{
    data: { id: string; title: string; titleEn: string }[];
    totalCount: number;
    groupCount: number;
  }> = new Observable();
  disableSubmitFormDetailsBtn: boolean = false;

  RequestStatus = RequestStatus;
  existingRequestAttachments!: Attachment[];

  organizationUnitsList: OrganizationUnit[] = [];
  compareFn = compareFn;
  showAccessUsers: boolean = false;
  mappedContainersList: { displayText: string; value: any }[] = [];
  readonly dropDownProperties = ['id', 'title', 'titleEn'];
  readonly dropDownPropertiesClass = [
    'id',
    'title',
    'titleEn',
    'classificationLevel',
  ];

  gregorianToday: NgbDateStruct = {
    day: new Date().getDate(),
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
  };

  hijriToday!: NgbDateStruct;
  @Output() nextStep: EventEmitter<{
    requestId: string;
  }> = new EventEmitter();
  @Output() previousStep: EventEmitter<void> = new EventEmitter();

  @ViewChild('visibleFileToUpload') visibleFileToUpload!: ElementRef;
  @ViewChild('hiddenFileToUpload') hiddenFileToUpload!: ElementRef;
  usersList$: Observable<{
    data: { id: string; name: string }[];
    totalCount: number;
  }> = new Observable();
  constructor(
    private languageService: LanguageService,
    private dialog: MatDialog,
    private router: Router,
    private location: Location,
    private translateService: TranslateService,
    private manageImportsExportsService: ManageImportsExportsService,
    private toastr: ToastrService,
    private activatedRoute: ActivatedRoute,
    private cdr: ChangeDetectorRef,
    private currencyPipe: CurrencyPipe,
    private usersService: UsersService
  ) {}

  ngOnInit(): void {
    this.lang = this.languageService.language;
    this.requestId = this.activatedRoute.snapshot.params['requestId'];
    this.initializeForm();
    this.intializeDropDownLists();
    this.usersList$ = this.usersService.getUsersList(
      {
        pageSize: 1000,
        pageIndex: 0,
      },
      undefined,
      undefined,
      ['id', 'name']
    );
    this.manageImportsExportsService.UmAlQuraCalendarService.getHijriDate(
      `${this.gregorianToday.year}/${this.gregorianToday.month}/${this.gregorianToday.day}`
    ).subscribe({
      next: (res) => {
        this.hijriToday = {
          day: parseInt(res.split('/')[2]),
          month: parseInt(res.split('/')[1]),
          year: parseInt(res.split('/')[0]),
        };
      },
    });

    if (this.requestId) {
      this.manageImportsExportsService.requestsService
        .getRequestById(this.requestId)
        .subscribe({
          next: (res) => {
            this.existingRequestAttachments = res.attachments;
            this.patchForm(res);
            // After patching, reload all dropdown lists so selects show all options
            this.intializeDropDownLists();
            this.form.get('requestType')?.disable();
            this.allowEditContainer = !res.isTransaction;
          },
        });
    }
  }

  intializeDropDownLists(): void {
    this.containersList$ =
      this.manageImportsExportsService.requestContainersService
        .getTransactionsListLookup(
          {
            pageSize: 100,
            pageIndex: 0,
          },
          undefined,
          undefined
        )
        .pipe(
          tap((response) => {
            this.mappedContainersList = response.data.map((container) => ({
              displayText: `(${container?.transactionNumber})-${container.title}`,
              value: container.id,
            }));
          })
        );

    this.foundationsList$ =
      this.manageImportsExportsService.foundationsService.getFoundationsList(
        {
          pageSize: 20,
          pageIndex: 0,
        },
        {
          parentId: null,
        },
        undefined,
        this.dropDownProperties
      );

    this.manageImportsExportsService.foundationsService
      .getFoundationsList(
        {
          pageSize: 10,
          pageIndex: 0,
        },
        {
          parentId: null,
        },
        undefined,
        this.dropDownProperties
      )
      .subscribe({
        next: (res) => {
          this.concernedFoundationsList = res.data;
        },
      });

    this.manageImportsExportsService.organizationUnitsService
      .getOrganizationUnitsList(
        {
          pageSize: 100,
          pageIndex: 0,
        },
        {
          type: OrganizationUnitType.Committee,
        }
      )
      .subscribe({
        next: (res) => {
          this.organizationUnitsList = res.data;
        },
      });

    this.manageImportsExportsService.classificationsService
      .getClassificationsList(
        {
          pageSize: 100,
          pageIndex: 0,
        },
        {
          isActive: true,
        },
        undefined,
        this.dropDownPropertiesClass
      )
      .subscribe({
        next: (res) => {
          this.classificationsList = res.data;
        },
      });

    this.manageImportsExportsService.prioritiesService
      .getPrioritiesList(
        {
          pageSize: 100,
          pageIndex: 0,
        },
        undefined,
        undefined,
        this.dropDownProperties
      )
      .subscribe({
        next: (res) => {
          this.prioritiesList = res.data;
        },
      });
    const classificationId = this.form?.get('classificationId')?.value;
    this.requestTypesList$ =
      this.manageImportsExportsService.requestTypesService.getRequestTypesList(
        {
          pageSize: 10,
          pageIndex: 0,
        },
        {
          classificationId,
          isTransaction: true,
        },
        undefined,
        this.dropDownProperties
      );

    this.containersList$.subscribe();
    this.foundationsList$.subscribe();
    this.subFoundationsList$.subscribe();
    this.requestTypesList$.subscribe();
    this.usersList$.subscribe();
  }

  onSelectedFoundationChanged(): void {
    const { foundation } = this.form.value;

    //Reset subFoundation field
    this.form.patchValue({
      subFoundation: null,
    });

    if (foundation) {
      this.subFoundationsList$ =
        this.manageImportsExportsService.foundationsService.getFoundationsList(
          {
            pageSize: 20,
            pageIndex: 0,
          },
          {
            parentId: foundation,
          },
          undefined,
          this.dropDownProperties
        );
    } else {
      this.subFoundationsList$ = of({ data: [], totalCount: 0 });
    }
  }

  onFoundationCleared(): void {
    //Reset subFoundation field
    this.form.patchValue({
      subFoundation: null,
    });

    this.subFoundationsList$ = of({ data: [], totalCount: 0, groupCount: -1 });
  }

  initializeForm(): void {
    this.form = new FormGroup(
      {
        id: new FormControl('', []),
        autoNumber: new FormControl('', []),
        importNumber: new FormControl('', []),
        classificationId: new FormControl('', [Validators.required]),
        users: new FormControl(null, []),
        requestType: new FormControl(null, [Validators.required]),
        title: new FormControl('', [Validators.required]),

        physicalHijriDate: new FormControl('', [Validators.required]),
        physicalGregorianDate: new FormControl('', [Validators.required]),

        deliveryHijriDate: new FormControl(
          { value: this.gregorianTodayDate, disabled: true },
          [Validators.required]
        ),
        deliveryGregorianDate: new FormControl(
          { value: this.gregorianTodayDate, disabled: true },
          [Validators.required]
        ),

        availabilityHijriDate: new FormControl('', []),
        availabilityGregorianDate: new FormControl('', []),

        priorityId: new FormControl('', [Validators.required]),
        physicalNumber: new FormControl('', [Validators.required]),
        deliveryNumber: new FormControl('', [Validators.required]),

        requestContainer: new FormControl(null, []),
        foundation: new FormControl('', [Validators.required]),
        subFoundation: new FormControl('', []),
        concernedFoundations: new FormControl('', [Validators.required]),
        committeeId: new FormControl('', []),

        creditsRequestedAmount: new FormControl('', [Validators.min(0)]),
        creditsApprovedAmount: new FormControl('', [Validators.min(0)]),
        costsRequestedAmount: new FormControl('', [Validators.min(0)]),
        costsApprovedAmount: new FormControl('', [Validators.min(0)]),

        note: new FormControl('', []),
        description: new FormControl('', []),

        attachmentInput: new FormControl('', []),
        attachments: new FormArray([], []),
        attachmentDescription: new FormControl('', []),
      },
      {
        validators: this.validateUsersBasedOnClassification(),
      }
    );

    this.deliveryHijriDateCalendarInput = moment(new Date())
      .locale('en')
      .format('yyyy-MM-DD');
  }

  private validateUsersBasedOnClassification(): ValidatorFn {
    return (form: AbstractControl): ValidationErrors | null => {
      const usersVal = form.get('users')?.value;
      if (this.showAccessUsers && (!usersVal || usersVal.length === 0)) {
        return {
          usersRequired: true,
        };
      }

      return null;
    };
  }

  patchForm(data: RequestDetails): void {
    const physicalHijriDateString = new Intl.DateTimeFormat(
      'en-u-ca-islamic-umalqura-nu-latn',
      {
        day: 'numeric',
        month: 'numeric',
        year: 'numeric',
      }
    ).format(new Date(data.physicalDate));
    // Step 1: Remove ' AH' and split the string by '/'
    const physicalHijriDateParts = physicalHijriDateString
      .replace(' AH', '')
      .split('/');

    // Step 2: Reorder the parts to match 'DD/MM/YYYY'
    const physicalHijriReorderedDate = `${physicalHijriDateParts[2]}/${physicalHijriDateParts[0]}/${physicalHijriDateParts[1]}`;

    ////////////////////////////////////////////////////////////////////////////////
    let availabilityHijriReorderedDate = '';

    if (data.availabilityDate) {
      const availabilityHijriDateString = new Intl.DateTimeFormat(
        'en-u-ca-islamic-umalqura-nu-latn',
        {
          day: 'numeric',
          month: 'numeric',
          year: 'numeric',
        }
      ).format(new Date(data.availabilityDate));
      // Step 1: Remove ' AH' and split the string by '/'
      const availabilityHijriDateParts = availabilityHijriDateString
        .replace(' AH', '')
        .split('/');

      // Step 2: Reorder the parts to match 'DD/MM/YYYY'
      availabilityHijriReorderedDate = `${availabilityHijriDateParts[2]}/${availabilityHijriDateParts[0]}/${availabilityHijriDateParts[1]}`;
    }
    ///////////////////////////////////////////////////////////////
    const deliveryHijriDateString = new Intl.DateTimeFormat(
      'en-u-ca-islamic-umalqura-nu-latn',
      {
        day: 'numeric',
        month: 'numeric',
        year: 'numeric',
      }
    ).format(new Date(data.deliveryDate));
    // Step 1: Remove ' AH' and split the string by '/'
    const deliveryHijriDateParts = deliveryHijriDateString
      .replace(' AH', '')
      .split('/');

    // Step 2: Reorder the parts to match 'DD/MM/YYYY'
    const deliveryHijriReorderedDate = `${deliveryHijriDateParts[2]}/${deliveryHijriDateParts[0]}/${deliveryHijriDateParts[1]}`;
    this.form.patchValue({
      id: data.id,
      classificationId: data.classification.id,
      requestType: data.requestType.id,
      title: data.title,

      physicalHijriDate: physicalHijriReorderedDate,
      physicalGregorianDate: data.physicalDate,

      deliveryHijriDate: deliveryHijriReorderedDate,
      deliveryGregorianDate: data.deliveryDate,

      availabilityHijriDate: availabilityHijriReorderedDate
        ? availabilityHijriReorderedDate
        : null,
      availabilityGregorianDate: data.availabilityDate,

      priorityId: data.priority?.id,
      autoNumber: data.autoNumber,
      physicalNumber: data.physicalNumber,
      deliveryNumber: data.deliveryNumber,

      requestContainer: data.requestContainer?.id,
      foundation: data.foundation.id,
      subFoundation: data.subFoundation?.id,
      concernedFoundations: data.concernedFoundations.map((cf) => cf.id),
      committeeId: data.committee?.id,

      creditsRequestedAmount: data.creditsRequestedAmount,
      creditsApprovedAmount: data.creditsApprovedAmount,
      costsRequestedAmount: data.costsRequestedAmount,
      costsApprovedAmount: data.costsApprovedAmount,

      note: data.note,
      description: data.description,
      status: data.status,
      attachmentDescription: data.attachmentDescription,
      ...(data.users && data.users.length
        ? ((this.showAccessUsers = true),
          {
            users: Array.isArray(data.users)
              ? data.users.map((f) => f?.id ?? f)
              : [],
          })
        : { users: [] }),
    });

    //patch hijri dates
    this.patchHijriDates({
      physicalDate: data.physicalDate,
      deliveryDate: data.deliveryDate,
      availabilityDate: data.availabilityDate,
    });

    //Handle adding attachments
    data.attachments.forEach((attachment) => {
      this.attachments.push(new FormControl(attachment));
    });
    this.cdr.detectChanges();
  }

  patchHijriDates(data: {
    physicalDate: string;
    deliveryDate: string;
    availabilityDate: string;
  }) {
    if (data.physicalDate) {
      const physicalDate = data.physicalDate?.split('T')[0];
      this.onPatchFormPhysicalGregorianDate({
        gregorianDate: {
          day: parseInt(physicalDate.split('-')[2]),
          month: parseInt(physicalDate.split('-')[1]),
          year: parseInt(physicalDate.split('-')[0]),
        },
      });
    }

    if (data.deliveryDate) {
      const deliveryDate = data.deliveryDate?.split('T')[0];
      this.onPatchFormDeliveryGregorianDate({
        gregorianDate: {
          day: parseInt(deliveryDate.split('-')[2]),
          month: parseInt(deliveryDate.split('-')[1]),
          year: parseInt(deliveryDate.split('-')[0]),
        },
      });
    }

    if (data.availabilityDate) {
      const availabilityDate = data.availabilityDate?.split('T')[0];
      this.onPatchFormAvailabilityGregorianDate({
        gregorianDate: {
          day: parseInt(availabilityDate.split('-')[2]),
          month: parseInt(availabilityDate.split('-')[1]),
          year: parseInt(availabilityDate.split('-')[0]),
        },
      });
    }
  }

  onPatchFormPhysicalHijriDate(date: { hijriDate: NgbDateStruct }): void {
    if (date.hijriDate) {
      this.manageImportsExportsService.UmAlQuraCalendarService.getGregorianDate(
        `${date.hijriDate.year}/${date.hijriDate.month}/${date.hijriDate.day}`
      ).subscribe({
        next: (res) => {
          this.form.patchValue(
            {
              physicalHijriDate: `${date.hijriDate.year}-${date.hijriDate.month}-${date.hijriDate.day}`,
              physicalGregorianDate: `${res.split('/')[0]}-${
                res.split('/')[1]
              }-${res.split('/')[2]}`,
            },
            { emitEvent: false }
          );
        },
      });
    } else {
      this.form.patchValue(
        {
          physicalHijriDate: null,
          physicalGregorianDate: null,
        },
        { emitEvent: false }
      );
    }
    this.form.get('physicalHijriDate')?.markAsTouched();
    this.form.get('physicalGregorianDate')?.markAsTouched();
  }

  onPatchFormPhysicalGregorianDate(date: {
    gregorianDate: NgbDateStruct;
  }): void {
    if (date.gregorianDate) {
      this.manageImportsExportsService.UmAlQuraCalendarService.getHijriDate(
        `${date.gregorianDate.year}/${date.gregorianDate.month}/${date.gregorianDate.day}`
      ).subscribe({
        next: (res) => {
          this.form.patchValue(
            {
              physicalHijriDate: `${res.split('/')[0]}-${res.split('/')[1]}-${
                res.split('/')[2]
              }`,
              physicalGregorianDate: `${date.gregorianDate.year}-${date.gregorianDate.month}-${date.gregorianDate.day}`,
            },
            { emitEvent: false }
          );
        },
      });
    } else {
      this.form.patchValue(
        {
          physicalHijriDate: null,
          physicalGregorianDate: null,
        },
        { emitEvent: false }
      );
    }

    this.form.get('physicalHijriDate')?.markAsTouched();
    this.form.get('physicalGregorianDate')?.markAsTouched();
  }

  onPatchFormAvailabilityHijriDate(date: { hijriDate: NgbDateStruct }): void {
    if (date.hijriDate) {
      this.manageImportsExportsService.UmAlQuraCalendarService.getGregorianDate(
        `${date.hijriDate.year}/${date.hijriDate.month}/${date.hijriDate.day}`
      ).subscribe({
        next: (res) => {
          this.form.patchValue(
            {
              availabilityHijriDate: `${date.hijriDate.year}-${date.hijriDate.month}-${date.hijriDate.day}`,
              availabilityGregorianDate: `${res.split('/')[0]}-${
                res.split('/')[1]
              }-${res.split('/')[2]}`,
            },
            { emitEvent: false }
          );
        },
      });
    } else {
      this.form.patchValue(
        {
          availabilityHijriDate: null,
          availabilityGregorianDate: null,
        },
        { emitEvent: false }
      );
    }

    this.form.get('availabilityHijriDate')?.markAsTouched();
    this.form.get('availabilityGregorianDate')?.markAsTouched();
  }

  onPatchFormAvailabilityGregorianDate(date: {
    gregorianDate: NgbDateStruct;
  }): void {
    if (date.gregorianDate) {
      this.manageImportsExportsService.UmAlQuraCalendarService.getHijriDate(
        `${date.gregorianDate.year}/${date.gregorianDate.month}/${date.gregorianDate.day}`
      ).subscribe({
        next: (res) => {
          this.form.patchValue(
            {
              availabilityHijriDate: `${res.split('/')[0]}-${
                res.split('/')[1]
              }-${res.split('/')[2]}`,
              availabilityGregorianDate: `${date.gregorianDate.year}-${date.gregorianDate.month}-${date.gregorianDate.day}`,
            },
            { emitEvent: false }
          );
        },
      });
    } else {
      this.form.patchValue(
        {
          availabilityHijriDate: null,
          availabilityGregorianDate: null,
        },
        { emitEvent: false }
      );
    }

    this.form.get('availabilityHijriDate')?.markAsTouched();
    this.form.get('availabilityGregorianDate')?.markAsTouched();
  }

  onPatchFormDeliveryHijriDate(date: { hijriDate: NgbDateStruct }): void {
    if (date.hijriDate) {
      this.manageImportsExportsService.UmAlQuraCalendarService.getGregorianDate(
        `${date.hijriDate.year}/${date.hijriDate.month}/${date.hijriDate.day}`
      ).subscribe({
        next: (res) => {
          this.form.patchValue(
            {
              deliveryHijriDate: `${date.hijriDate.year}-${date.hijriDate.month}-${date.hijriDate.day}`,
              deliveryGregorianDate: `${res.split('/')[0]}-${
                res.split('/')[1]
              }-${res.split('/')[2]}`,
            },
            { emitEvent: false }
          );
        },
      });
    } else {
      this.form.patchValue(
        {
          deliveryHijriDate: null,
          deliveryGregorianDate: null,
        },
        { emitEvent: false }
      );
    }

    this.form.get('deliveryHijriDate')?.markAsTouched();
    this.form.get('deliveryGregorianDate')?.markAsTouched();
  }

  onPatchFormDeliveryGregorianDate(date: {
    gregorianDate: NgbDateStruct;
  }): void {
    this.manageImportsExportsService.UmAlQuraCalendarService.getHijriDate(
      `${date.gregorianDate.year}/${date.gregorianDate.month}/${date.gregorianDate.day}`
    ).subscribe({
      next: (res) => {
        this.form.patchValue(
          {
            deliveryHijriDate: `${res.split('/')[0]}-${res.split('/')[1]}-${
              res.split('/')[2]
            }`,
            deliveryGregorianDate: `${date.gregorianDate.year}-${date.gregorianDate.month}-${date.gregorianDate.day}`,
          },
          { emitEvent: false }
        );
        this.form.get('deliveryHijriDate')?.markAsTouched();
        this.form.get('deliveryGregorianDate')?.markAsTouched();
      },
    });
  }

  onClassificationChanges(): void {
    const classificationId = this.form.get('classificationId')!.value;

    const classificationObj = this.classificationsList.find(
      (c) => c.id === classificationId
    );
    this.manageImportsExportsService.classificationsService
      .getClassificationUsersById(classificationId)
      .subscribe((res) => {
        this.showAccessUsers =
          classificationObj?.classificationLevel ===
          ClassificationLevel.Restricted
            ? true
            : false;
        this.form.patchValue({
          users: res.map((u) => u.id),
        });
      });
  }

  searchOnContainers(event: { term: string; items: any[] }) {
    this.containersList$ =
      this.manageImportsExportsService.requestContainersService
        .getTransactionsListLookup(
          {
            pageSize: 10,
            pageIndex: 0,
          },
          {
            searchKeyword: event.term,
          },
          undefined,
          undefined
        )
        .pipe(
          tap((response) => {
            this.mappedContainersList = response.data.map((container) => ({
              displayText: `(${container.transactionNumber})-${container.title}`,
              value: container.id,
            }));
          })
        );
    this.containersList$.subscribe();
  }

  searchOnFoundations(event: { term: string; items: any[] }) {
    this.foundationsList$ =
      this.manageImportsExportsService.foundationsService.getFoundationsList(
        {
          pageSize: 10,
          pageIndex: 0,
        },
        {
          parentId: null,
          searchKeyword: event.term,
        },
        undefined,
        this.dropDownProperties
      );
    this.foundationsList$.subscribe();
  }

  searchOnSubFoundations(event: { term: string; items: any[] }) {
    const { foundation } = this.form.value;

    if (foundation) {
      this.subFoundationsList$ =
        this.manageImportsExportsService.foundationsService.getFoundationsList(
          {
            pageSize: 10,
            pageIndex: 0,
          },
          {
            parentId: foundation,
            searchKeyword: event.term,
          },
          undefined,
          this.dropDownProperties
        );
    }
  }

  searchOnConcernedFoundations(event: { term: string; items: any[] }) {
    this.manageImportsExportsService.foundationsService
      .getFoundationsList(
        {
          pageSize: 10,
          pageIndex: 0,
        },
        {
          parentId: null,
          searchKeyword: event.term,
        },
        undefined,
        this.dropDownProperties
      )
      .subscribe({
        next: (res) => {
          this.concernedFoundationsList = res.data;
        },
      });
  }

  searchOnRequestTypes(event: { term: string; items: any[] }): void {
    const classificationId = this.form?.get('classificationId')?.value;

    if (classificationId) {
      this.requestTypesList$ =
        this.manageImportsExportsService.requestTypesService.getRequestTypesList(
          {
            pageSize: 10,
            pageIndex: 0,
          },
          {
            searchKeyword: event.term,
            classificationId,
            isTransaction: true,
          },
          undefined,
          this.dropDownProperties
        );
    }
  }

  onSubmit(): void {
    if (!this.form.valid) {
      return;
    }

    this.disableSubmitFormDetailsBtn = true;

    const dataToSend = this.mapUpdateRequestDataToBeSend();

    //Update import
    this.manageImportsExportsService.requestsService
      .updateImport(this.requestId, dataToSend)
      .subscribe({
        next: (res) => {
          this.disableSubmitFormDetailsBtn = false;
          this.toastr.success(
            this.translateService.instant(
              `ImportsExportsModule.AddImportComponent.editedImportSuccessfully`
            )
          );
          this.router.navigate(['imports-exports']);
        },
        error: (err) => this.handleErrorResponse(err),
      });
  }

  handleErrorResponse(err?: any): void {
    this.disableSubmitFormDetailsBtn = false;
    this.toastr.error(
      this.translateService.instant('shared.SomethingWentWrong')
    );
  }

  openSuccessDialog(res: {
    requestId: string;
    requestAutoNumber: number;
    requestImportNumber: number;
    requestStatus: RequestStatus;
  }): void {
    const dialogRef = this.dialog.open(SuccessModalComponent, {
      minWidth: '31.25rem',
      maxWidth: '31.25rem',
      panelClass: 'action-modal',
      autoFocus: false,
      disableClose: true,
      data: {
        title: 'shared.processDone',
        content: this.translateService.instant('shared.importSerialNumberIs'),
        specialContent: ` (${res.requestAutoNumber})`,
        requestId: res.requestId,
      },
    });

    dialogRef
      .afterClosed()
      .subscribe(
        (dialogResult: { statusCode: ModalStatusCode; status: string }) => {
          this.nextStep.emit({ requestId: res.requestId });
        }
      );
  }

  private mapUpdateRequestDataToBeSend(): UpdateRequestCommand {
    const {
      title,
      description,
      physicalGregorianDate,
      deliveryGregorianDate,
      availabilityGregorianDate,
      creditsRequestedAmount,
      creditsApprovedAmount,
      costsRequestedAmount,
      costsApprovedAmount,
      physicalNumber,
      deliveryNumber,
      note,
      priorityId,
      requestContainer,
      foundation,
      subFoundation,
      concernedFoundations,
      committeeId,
      attachments,
      attachmentDescription,
      users,
      classificationId,
    } = this.form.getRawValue();

    const dataToSend: UpdateRequestCommand = {
      title,
      description,
      physicalDate: physicalGregorianDate,
      deliveryDate: deliveryGregorianDate,
      availabilityDate: availabilityGregorianDate
        ? availabilityGregorianDate
        : '',
      creditsRequestedAmount,
      creditsApprovedAmount,
      costsRequestedAmount,
      costsApprovedAmount,
      physicalNumber,
      deliveryNumber,
      note,
      priorityId,
      classificationId,
      requestContainerId: requestContainer,
      foundationId: foundation,
      subFoundationId: subFoundation ? subFoundation : null,
      concernedFoundationsIds: Array.isArray(concernedFoundations)
        ? concernedFoundations.map((ele) =>
            typeof ele === 'object' ? ele.id : ele
          )
        : [],
      committeeId: committeeId ? committeeId : null,
      attachmentsIds: Array.isArray(attachments)
        ? attachments.map((att) => (typeof att === 'object' ? att.id : att))
        : [],
      attachmentDescription,
      usersIds:
        this.showAccessUsers && users && users.length
          ? users.map((ele) => (typeof ele === 'object' ? ele.id : ele))
          : [],
    };

    return dataToSend;
  }

  get attachmentInput(): FormControl {
    return this.form?.get('attachmentInput') as FormControl;
  }

  get attachments(): FormArray {
    return this.form?.get('attachments') as FormArray;
  }

  onInsertFileToList(): void {
    if (this.attachmentInput.value) {
      this.manageImportsExportsService.wopiFilesService
        .createFile(this.attachmentInput.value.fileBlob)
        .subscribe({
          next: (res) => {
            this.attachments.push(new FormControl('', []));

            const attachmentsLength = this.attachments.length;

            this.attachments.controls[
              attachmentsLength > 0 ? attachmentsLength - 1 : 0
            ]?.patchValue({ ...this.attachmentInput.value, fileId: res });

            this.attachmentInput.setValue(null);

            const hiddenFileToUploadHtmlElement: HTMLInputElement =
              this.hiddenFileToUpload.nativeElement;
            hiddenFileToUploadHtmlElement.disabled = false;

            const visibleFileToUploadHtmlElement: HTMLInputElement =
              this.visibleFileToUpload.nativeElement;

            visibleFileToUploadHtmlElement.value = '';
            visibleFileToUploadHtmlElement.disabled = false;
          },
          error: (err) => {},
        });
    }
  }

  onAddFile(): void {
    const hiddenFileToUploadHtmlElement: HTMLInputElement =
      this.hiddenFileToUpload.nativeElement;
    hiddenFileToUploadHtmlElement.value = '';
    hiddenFileToUploadHtmlElement.click();
  }

  onFileChange(e: any): void {
    const filesArray = e.target.files;

    if (filesArray.length > 0) {
      this.uploadFile(filesArray[0]);
    }
  }

  uploadFile(file: File): void {
    this.attachmentInput.patchValue({
      fileBlob: file,
      fileType: '.' + file.name.split('.').pop(), //.pdf
      fileName: file.name,
      fileId: '',
      filePath: '',
    });
    const hiddenFileToUploadHtmlElement: HTMLInputElement =
      this.hiddenFileToUpload.nativeElement;
    hiddenFileToUploadHtmlElement.disabled = true;

    const visibleFileToUploadHtmlElement: HTMLInputElement =
      this.visibleFileToUpload.nativeElement;

    visibleFileToUploadHtmlElement.value = file.name;
    visibleFileToUploadHtmlElement.disabled = true;
  }

  onDeleteFile(index: number): void {
    this.attachments.removeAt(index);
  }

  onViewAttachment(file: any): void {
    // const raw = this.attachments.controls[index]?.value;
    if (!file) return;

    // Normalize attachment object to support both legacy and new structures
    const attachment = {
      fileBlob: file.fileBlob || file.file || null,
      fileType: file.fileType || file.contentType || '',
      fileName: file.fileName || file.name || '',
      fileId: file.fileId || file.id || '',
      filePath: file.filePath || file.path || '',
    };

    if (attachment.fileType === '.pdf') {
      //We need to fetch pdf file from server
      this.manageImportsExportsService.wopiFilesService
        .getTemporaryFile(attachment.fileId)
        .subscribe({
          next: (res) => {
            this.dialog
              .open(EditFileWithBarcodeModalComponent, {
                minWidth: '62.5rem',
                maxWidth: '62.5rem',
                maxHeight: '90vh',
                panelClass: 'action-modal',
                autoFocus: false,
                disableClose: true,
                data: {
                  fileBlob: res,
                  fileType: attachment.fileType, //.pdf
                  fileName: attachment.fileName,
                  fileId: attachment.fileId,
                  filePath: attachment.filePath,
                  requestId: this.requestId,
                },
              })
              .afterClosed()
              .subscribe((res) => {});
          },
        });
    } else {
      //The file is not pdf,Just open the dialog
      this.dialog
        .open(EditFileWithBarcodeModalComponent, {
          minWidth: '95vw',
          autoFocus: false,
          disableClose: true,
          data: {
            fileBlob: attachment.fileBlob,
            fileType: attachment.fileType, //.doc
            fileName: attachment.fileName,
            fileId: attachment.fileId,
            filePath: attachment.filePath,
            requestId: this.requestId,
          },
        })
        .afterClosed()
        .subscribe((res) => {});
    }
  }

  // Used to get a strongly typed FormControl
  getFormControlByIndex(formArray: FormArray, index: number): FormControl {
    return formArray.controls[index] as FormControl;
  }

  isTouched(controlName: string): boolean | undefined {
    return isTouched(this.form, controlName);
  }

  goToLastPage(): void {
    this.location.back();
  }

  onGoToPreviousStep(): void {
    this.previousStep.emit();
  }

  onSetIfUserIsTouched(touched: boolean): void {
    if (touched) {
      this.form.get('users')?.markAsTouched();
    } else {
      this.form.get('users')?.markAsUntouched();
    }
  }

  // Handle files dropped/uploaded from app-upload-attachment
  uploadedFileNames: string[] = [];
  attachmentIds: string[] = [];
  onFileDropped(e: any): void {
    for (const [key, value] of e.entries()) {
      if (
        value instanceof File &&
        !this.uploadedFileNames.includes(value.name)
      ) {
        this.uploadedFileNames.push(value.name);
        this.manageImportsExportsService.wopiFilesService
          .createFile(value)
          .subscribe((res) => {
            if (res) {
              const attachmentObj = {
                contentType: '.' + value.name.split('.').pop(),
                fileType: '.' + value.name.split('.').pop(),
                name: value.name,
                id: res,
                path: '',
              };
              this.attachments.push(new FormControl(attachmentObj));
              this.attachmentIds.push(res);
              this.cdr.detectChanges();
            }
          });
      }
    }
  }
  onFileDroppedd(e: any): void {
    for (const [key, value] of e.entries()) {
      if (
        value instanceof File &&
        !this.uploadedFileNames.includes(value.name)
      ) {
        this.uploadedFileNames.push(value.name);
        this.manageImportsExportsService.wopiFilesService
          .createFile(value)
          .subscribe((res) => {
            if (res) {
              // Create attachment object and push to FormArray
              const attachmentObj = {
                fileBlob: value,
                fileType: '.' + value.name.split('.').pop(),
                fileName: value.name,
                fileId: res,
                filePath: '',
              };
              this.attachments.push(new FormControl(attachmentObj));
              this.attachmentIds.push(res);
              this.cdr.detectChanges();
            }
          });
      }
    }
  }

  // Handle file removal from app-upload-attachment
  onAttachmentRemoved(file: any): void {
    // Remove file from attachments FormArray by fileId or fileName
    const index = this.attachments.controls.findIndex(
      (ctrl: FormControl) =>
        ctrl.value.fileId === file.id || ctrl.value.fileName === file.name
    );
    if (index > -1) {
      this.attachments.removeAt(index);
      this.cdr.detectChanges();
    }
  }
  get attachmentFiles() {
    return this.attachments.controls.map((c) => c.value);
  }
}


