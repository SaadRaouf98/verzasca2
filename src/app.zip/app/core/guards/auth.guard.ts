/* import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  CanMatch,
  Route,
  Router,
  RouterStateSnapshot,
  UrlSegment,
} from '@angular/router';
import { AuthService } from '../services/auth/auth.service';
import { Observable, of, switchMap } from 'rxjs';
import { RemoveAuthData } from '@core/utils/local-storage-data';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate, CanMatch {
  constructor(private _authService: AuthService, private _router: Router) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    let redirectUrl = state.url;
    return this._check(redirectUrl);
  }


  canMatch(
    route: Route,
    segments: UrlSegment[]
  ): Observable<boolean> | Promise<boolean> | boolean {
    const redirectUrl = localStorage.getItem('last_url') ?? '/';
    return this._check(redirectUrl, route);
  }

 
  private _check(redirectURL: string, route?: Route): Observable<boolean> {
    // Check the authentication status
    return this._authService.check().pipe(
      switchMap((authenticated) => {
        // If the user is not authenticated...

        if (!authenticated) {
          // Redirect to the login page with redirect parameter
          this._router
            .navigate(['auth/login'], { queryParams: { redirectURL } })
            .then();

          // Clear Local Storage
          RemoveAuthData();

          // Prevent the access
          return of(false);
        } else {
          const role = route?.data && route?.data['role'];
          /* if (role && role !== this._authService.getUserType()) {
            this._router.navigate(['/']).then();
            return of(false);
          } */
/* }

        // Allow the access
        // return this._authService.getUserDetails();
        return of(true);
      })
    );
  }
} */

import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  Router,
} from '@angular/router';
import { AuthService } from '@core/services/auth/auth.service';
import { NgxPermissionsService } from 'ngx-permissions';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(
    private authService: AuthService,
    private router: Router,
    private ngxPermsissionsService: NgxPermissionsService
  ) {}

  /**
   * Activates the route if the user is already logged in
   *
   * @param {ActivatedRouteSnapshot} route
   * @param {RouterStateSnapshot} state
   * @return {*}  {(Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree)}
   * @memberof LoginGuard
   */
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    if (!this.authService.isLoggedIn()) {
      this.router.navigate(['/auth/login']);
      return false;
    }

    return this.authService
      .setCurrentUserPermissions()
      .toPromise()
      .then((res) => {
        this.ngxPermsissionsService.loadPermissions(res as string[]);
        return true;
      })
      .catch((err) => {
        return false;
      });
  }
}
