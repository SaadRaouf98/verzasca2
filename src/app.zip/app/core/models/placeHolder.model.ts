export interface PlaceHolder {
  page: number;
  top: number;
  left: number;
  width: number;
  height: number;
}
