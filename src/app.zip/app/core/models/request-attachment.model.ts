export interface RequestAttachment {
  id?: string;
  file?: File;
  isUpdated: boolean;
  isDeleted: boolean;
}
