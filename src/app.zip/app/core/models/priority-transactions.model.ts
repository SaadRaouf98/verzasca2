export interface PriorityTransactions {
  values: [
    {
      id: string;
      title: string;
      count: number;
    }
  ];
  total: number;
}
