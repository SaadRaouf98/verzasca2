export interface PriorityRecords {
  values: {
    id: string;
    title: string;
    count: number;
  }[];
  total: number;
}
