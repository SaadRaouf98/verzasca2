export interface DocumentsStatistics {
  notesCount: number;
  lettersCount: number;
  total: number;
}
