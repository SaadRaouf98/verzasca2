export interface SystematicImports {
  values: {
    id: string;
    title: string;
    count: number;
  }[];
  total: number;
}
