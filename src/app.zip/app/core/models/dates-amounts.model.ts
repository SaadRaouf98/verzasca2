export interface DatesAmounts {
  title?: string;
  date: string;
  creditsRequestedAmount: number;
  creditsApprovedAmount: number;
  costsRequestedAmount: number;
  costsApprovedAmount: number;
}
