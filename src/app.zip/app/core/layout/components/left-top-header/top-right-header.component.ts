import { Component, OnInit, Input } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { Router } from '@angular/router';
import { AuthService } from '@core/services/auth/auth.service';
import { NotificationsHubService } from '@core/services/backend-services/notifications-hub.service';
import { LanguageService } from '@core/services/language.service';
interface MenuItem {
  label: string;
  icon: string; // e.g. your SVG/icon-font class
  route?: string; // where to navigate
  children?: MenuItem[]; // for dropdowns
  isOpen?: boolean; // track open state
}
@Component({
  selector: 'app-top-right-header',
  templateUrl: './top-right-header.component.html',
  styleUrls: ['./top-right-header.component.scss'],
})
export class TopRightHeaderComponent implements OnInit {
  selectedOption = '';
  menu: MenuItem[] = [
    {
      label: 'الخدمات الإلكترونية',
      icon: 'header-services',
      children: [
        { label: 'قسم ١', icon: '', route: '/structure/1' },
        { label: 'قسم ٢', icon: '', route: '/structure/2' },
      ],
    },
    {
      label: 'هيكل المنشأة',
      icon: 'header-structure',
      route: '/system-management/secretarial-structure',
    },
    {
      label: 'آخر الأخبار',
      icon: 'header-news',
      route: '/home/posts',
    },
    {
      label: 'الحضور والانصراف',
      icon: 'header-attendance',
      route: '/time-attendance',
    },
  ];
  constructor(
    private languageService: LanguageService,
    private authService: AuthService,
    private router: Router,
    private notificationsHubService: NotificationsHubService
  ) {}

  ngOnInit() {}
  toggle(item: MenuItem, open: boolean) {
    item.isOpen = open;
  }
}
