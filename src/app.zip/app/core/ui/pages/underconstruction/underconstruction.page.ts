import { Component } from '@angular/core';

@Component({
  selector: 'app-underconstruction',
  templateUrl: './underconstruction.page.html',
  styleUrls: ['./underconstruction.page.scss']
})
export class UnderconstructionPage {

}
