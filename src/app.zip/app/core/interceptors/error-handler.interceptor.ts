import { MatDialog } from '@angular/material/dialog';
import { Injectable, Injector } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
} from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, retryWhen, mergeMap, delay } from 'rxjs/operators';
import { ErrorDialogComponent } from '@shared/components/error-dialog/error-dialog.component';

@Injectable({
  providedIn: 'root',
})
export class ErrorHandlerInterceptor implements HttpInterceptor {
  constructor(private injector: Injector) {}

  intercept(
    request: HttpRequest<unknown>,
    next: HttpHandler
  ): Observable<HttpEvent<unknown>> {
    // Retrying 3 times before throwing the error (A time every 0.5s)
    let counter = 0;
    let matDialog = this.injector.get(MatDialog);
    return next.handle(request).pipe(
      retryWhen((errors) => {
        return errors.pipe(
          mergeMap((err: HttpErrorResponse) => {
            if (err && err.error instanceof ProgressEvent && counter < 3) {
              counter++;
              return of(err);
            }
            return throwError(err);
          }),
          delay(1000)
        );
      }),
      catchError(
        (err: HttpErrorResponse, catch$: Observable<HttpEvent<unknown>>) => {
          matDialog.closeAll();
          matDialog.open(ErrorDialogComponent, {
            width: '600px',
            autoFocus: false,
            disableClose: true,
            data: err,
          });

          return throwError(err);
        }
      )
    );
  }
}

