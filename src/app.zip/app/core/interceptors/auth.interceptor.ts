import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { AuthService } from '../services/auth/auth.service';
import { catchError, timeout } from 'rxjs/operators';
import { Injectable, Injector } from '@angular/core';
import { AuthUtils } from '../helpers/auth.utils';
import { MatDialog } from '@angular/material/dialog';
import { ErrorDialogComponent } from '@shared/components/error-dialog/error-dialog.component';
import { LanguageService } from '@core/services/language.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(
    private authService: AuthService,
    private injector: Injector,
    private languageService: LanguageService
  ) { }

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    // Clone the request object
    let newReq = req.clone();
    const token = this.authService.getToken();
    if (token && !AuthUtils.isTokenExpired(token)) {
      // Check if the request body is of FormData type and if it is, then don't add content-type header
      if (req.body instanceof FormData) {
        newReq = req.clone({
          headers: req.headers
            .set('Authorization', 'Bearer ' + token)
            .set('Accept-Language', this.languageService.language),
        });
      } else {
        newReq = req.clone({
          headers: req.headers
            .set('content-type', 'application/json')
            .set('Authorization', 'Bearer ' + token)
            .set('Accept-Language', this.languageService.language),
        });
      }

      // check if req is PUT,PATCH or DELETE and req body has _etag then add it to headers
      if (
        ['PUT', 'PATCH', 'DELETE'].includes(newReq.method) &&
        newReq.body &&
        newReq.body._etag
      ) {
        newReq = newReq.clone({
          headers: newReq.headers.set('If-Match', req.body._etag),
        });
      }
    }

    let reqTimeOut = 5000;
    if (req.url.includes('/api/wopi/files') || req.url.includes("regularreports")) {
      reqTimeOut = 9900000;
    }

    // Response
    return next.handle(newReq).pipe(
      catchError((error) => {
        // Catch "401 Unauthorized" responses
        if (error instanceof HttpErrorResponse && error.status === 401) {
          this.authService.authenticated = false;
          this.authService.signInUsingRefreshToken().subscribe({
            next: (accessToken) => {
              //Retry the last request
              newReq = req.clone({
                headers: req.headers.set(
                  'Authorization',
                  'Bearer ' + accessToken
                ),
              });
              next.handle(newReq);
            },
            error: (error) => { },
          });
        } else {
          // For other errors (4xx, 5xx), show dialog and throw without making duplicate request
          const matDialog = this.injector.get(MatDialog);
          matDialog.closeAll();
          matDialog.open(ErrorDialogComponent, {
            width: '600px',
            autoFocus: false,
            disableClose: true,
            data: error,
          });
          return throwError(() => error);
        }

        return throwError(() => error);
      })
    );
  }
}
