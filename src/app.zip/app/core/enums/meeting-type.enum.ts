export enum MeetingType {
  Committee = 1, //لجنة
  Internal = 2, // داخلي
}
