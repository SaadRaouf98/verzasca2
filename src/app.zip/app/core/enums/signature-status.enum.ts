export enum SignatureStatus {
  Active = 1,
  Inactive = 2,
}
