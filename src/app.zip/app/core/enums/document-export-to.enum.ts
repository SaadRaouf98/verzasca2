export enum DocumentExportTo {
  RC = 1,
  EE = 2,
}
