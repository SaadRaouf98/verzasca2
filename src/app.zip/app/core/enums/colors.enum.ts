export enum Colors {
    RED = '#CA102F',
    GREEN = '#02C389',
}