export enum DeliveryReceiptAttachmentType {
  Original = 1, //اصل
  Copy = 2, // صورة
  USB = 3, // فلاش
  Other = 4, // أخري
}
