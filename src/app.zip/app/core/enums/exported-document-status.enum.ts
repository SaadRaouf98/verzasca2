export enum ExportedDocumentStatus {
  Draft = 1,
  /// <summary>
  /// Committee signatures
  /// </summary>
  InProgress = 2,
  Exported = 3,
  /// <summary>
  /// Remove export number and archive uncompleted document
  /// </summary>
  Deleted = 4,
  /// <summary>
  /// Keep export number reserved and archive document
  /// </summary>
  Archived = 5,
}
