export enum DocumentStatus {
  UnderProcessing = 1,
}
