export enum ExportableDocumentActionType {
  Sign = 1, // تم التوقيع الكترونيا
  Conservatism = 2, // "إبداء تحفظ، "نص التحفظ
  OpinionRefrain = 3, // الامتناع عن إبداء الرأي
}
