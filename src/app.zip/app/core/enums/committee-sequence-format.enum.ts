export enum CommitteeSequenceFormat {
  DateNumber = 1, //رقم مسلسل وتاريخ
  YearNumber = 2, //رقم مسلسل مع السنه
  Number = 3, //رقم مسلسل
}
