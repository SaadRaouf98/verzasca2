export enum LoginUserTokenStatus {
  Token = 1,
  Otp = 2,
}
