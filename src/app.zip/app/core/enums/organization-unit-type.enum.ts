export enum OrganizationUnitType {
  Committee = 1,
  Secretariate = 2, //أمانة
  SecretariateBranch = 3,
  Department = 4, // أقسام
}
