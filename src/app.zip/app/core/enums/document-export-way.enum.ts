export enum DocumentExportWay {
  None = 1,
  Mail = 2,
  Email = 3,
  Fax = 4,
  Handover = 5,
  Other = 6,
}
