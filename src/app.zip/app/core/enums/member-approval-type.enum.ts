export enum MemberApprovalType {
  Approved = 1,
  Rejected = 2,
}
