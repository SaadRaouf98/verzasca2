export enum NotificationCategory {
  Requests = 1,
  Inquiries,
  Records,
  Notes,
  Reports,
  Letters,
  Documents,
}
