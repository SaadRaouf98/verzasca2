export enum Events {
    SCROLL = 'scroll',
    ENTER = 'enter',
}