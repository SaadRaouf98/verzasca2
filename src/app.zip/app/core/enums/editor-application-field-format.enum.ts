export enum ApplicationFieldFormat {
  HighEdit = 8,
  MSWord = 7,
  MSWordTXFormFields = 2,
  None = 0,
}
