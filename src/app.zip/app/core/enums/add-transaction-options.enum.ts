export enum AddTransactionOptions {
  NewRequest = 1,
  AddToRequest = 2,
  Document = 3,
}
