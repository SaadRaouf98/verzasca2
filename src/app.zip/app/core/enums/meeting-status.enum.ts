export enum MeetingStatus {
  Draft = 1,
  Scheduled,
  Canceled,
  Closed,
  Confirmed, // after operator confirm attendance
}
