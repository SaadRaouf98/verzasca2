export enum WorkflowLinkUserAction {
  Edit = 1,
  Delete = 2,
}
