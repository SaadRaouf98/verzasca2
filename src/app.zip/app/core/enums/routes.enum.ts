export enum RouteConstants {
  PendingRequest = 'pending-transactions',
  DETAILS = 'details',
  Transactions = 'transactions',
  MANAGERECORDS = 'manage-records'
}
