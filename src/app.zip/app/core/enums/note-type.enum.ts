export enum NoteType {
  ForInformation = 1, // للاطلاع والاحاطة
  CloseRequest = 2, // اقفال قيد
  RequestStatement = 3, //طلب افادة من جهة خارجية
  Other = 4, //اخري
}
