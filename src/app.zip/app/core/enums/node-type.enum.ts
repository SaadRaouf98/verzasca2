export enum NodeType {
  Main = 1, //main node
  Secondary = 2, // secondary node
}
