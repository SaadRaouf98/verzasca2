export enum TimeFilterType {
  Daily = 1,
  Weekly = 2,
  Monthly = 3,
  Custom = 4,
}
