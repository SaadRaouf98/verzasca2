export enum InsertionMode {
  AboveTheText = 524290,
  AsCharacter = 1,
  BelowTheText = 262146,
  DisplaceCompleteLines = 4,
  DisplaceText = 8,
  FixedOnPage = 131072,
  MoveWithText = 65536,
}
