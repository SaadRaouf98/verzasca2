export enum RegularReportBoardType {
  Holder = 1,
  File = 2,
}
