export enum ClassificationLevel {
  Unrestricted = 1, // فير مقيد
  Restricted = 2, // مقيد
}
