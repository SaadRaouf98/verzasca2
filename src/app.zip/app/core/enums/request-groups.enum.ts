export enum RequestGroups {
  Group1 = 1,
  Group2 = 2,
  Group3 = 3,
  Group4 = 4,
  Group5 = 5,
  Group6 = 6,
}
