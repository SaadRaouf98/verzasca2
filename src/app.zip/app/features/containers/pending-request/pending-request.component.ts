import { CommonModule } from '@angular/common';
import {
  Component,
  CUSTOM_ELEMENTS_SCHEMA,
  DestroyRef,
  inject,
  OnInit,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute, Router } from '@angular/router';
import { RequestStatusArray } from '@core/enums/request-status.enum';
import { RouteConstants } from '@core/enums/routes.enum';
import { Entity } from '@core/models/entity.model';
import {
  PendingRequest,
  PendingRequestsFiltersForm,
} from '@core/models/pending-request.model';
import { FoundationsSearchService } from '@core/services/search-services/foundations-search.service';
import { FromDateToDateSearchService } from '@core/services/search-services/from-date-to-date-search.service';
import { RequestTypesSearchService } from '@core/services/search-services/request-types-search.service';
import { UsersSearchService } from '@core/services/search-services/users-search.service';
import { FiltersComponent } from '@features/components/pending-request/filters/filters.component';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { ManagePendingTransactionsService } from '@pages/pending-transactions/services/manage-pending-transactions.service';
import { TableListComponent } from '@shared/new-components/table-list/table-list.component';
import {
  catchError,
  debounceTime,
  finalize,
  forkJoin,
  Subject,
  tap,
} from 'rxjs';

@Component({
  selector: 'app-pending-request',
  templateUrl: './pending-request.component.html',
  styleUrls: ['./pending-request.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    TranslateModule,
    FiltersComponent,
    TableListComponent,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class PendingRequestComponent implements OnInit {
  destroyRef = inject(DestroyRef);
  private translate = inject(TranslateService);
  private managePendingTransactionsService = inject(
    ManagePendingTransactionsService
  );
  readonly usersSearchService = inject(UsersSearchService);
  readonly foundationsSearchService = inject(FoundationsSearchService);
  readonly requestTypesSearchService = inject(RequestTypesSearchService);
  readonly fromDateToDateSearchService = inject(FromDateToDateSearchService);
  readonly router = inject(Router);
  private activatedRoute = inject(ActivatedRoute);
  prioritiesList: Entity[] = [];
  nextStepsList: string[] = [];
  foundationsList: any[] = [];
  usersList: any[] = [];
  requestTypesList: any[] = [];

  //Table
  private readonly DEFAULT_PAGE_SIZE = 20;
  private readonly DEFAULT_PAGE_NUMBER = 0;
  pageNumber: number = this.DEFAULT_PAGE_NUMBER;
  pageSize: number = this.DEFAULT_PAGE_SIZE;
  totalElements: number = 0;
  filterText = '';
  columns: string[] = [];
  columnsConfig: any[] = [];
  items: PendingRequest[] = [];
  requestsSource!: PendingRequest[];
  filtersData: PendingRequestsFiltersForm = {} as PendingRequestsFiltersForm;
  isLoading: boolean = false;
  isError: boolean = false;
  status: { id: number; title: string }[] = [];
  selectedFilters: { [key: string]: any } = {};
  allFilters: PendingRequestsFiltersForm = {};
  private loadDataSubject = new Subject<void>();
  private isResetting = false;
  constructor() {}

  ngOnInit() {
    this.isLoading = true;
    this.initConfigsAndLoadData();
    this.loadDataSubject
      .pipe(
        debounceTime(300), // Wait 300ms after last emission
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(() => {
        this.performLoadData();
      });
  }

  initConfigsAndLoadData() {
    // Trigger the search so the streams emit values
    this.usersSearchService.searchOnUsers();
    this.foundationsSearchService.searchOnFoundations();
    this.requestTypesSearchService.searchOnRequestTypes();

    forkJoin({
      priorities:
        this.managePendingTransactionsService.prioritiesService.getPrioritiesList(
          { pageSize: 50, pageIndex: 0 },
          undefined,
          undefined,
          ['id', 'title', 'titleEn']
        ),
      requestTypes: this.requestTypesSearchService.requestTypesList$,
      currentSteps:
        this.managePendingTransactionsService.requestsService.getCurrentStepsList(),
      users: this.usersSearchService.usersList$,
      foundations: this.foundationsSearchService.foundationsList$,
    })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((results) => {
        // this.prioritiesList = [
        //   {
        //     id: '',
        //     title: this.translate.instant('shared.all'),
        //     titleEn: 'All',
        //     description: '',
        //     descriptionEn: '',
        //   },
        //   ...results.priorities.data,
        // ];
        this.prioritiesList = results.priorities.data;
        this.requestTypesList = results.requestTypes.data;
        this.nextStepsList = results.currentSteps;
        this.usersList = results.users.data;
        this.foundationsList = results.foundations.data;
        this.status = RequestStatusArray;
        this.initializeColumnConfig();
        this.initializeColumns();
        this.loadData();
      });
  }

  initializeColumns() {
    this.columns = [
      'status',
      'importNumber',
      'title',
      'requestType',
      'priority',
      'nextStep',
      'foundation',
      'exportType',
      'deliveryDate',
      'mainConsultant',
      'actions',
    ];
  }
  initializeColumnConfig() {
    this.columnsConfig = [
      {
        label: 'shared.status',
        type: 'statusIcon',
        hasFilter: true,
        menuData: this.status,
      },
      {
        label: 'ManageDocumentsModule.AddDocumentPage.incomingNumber',
        type: 'text',
      },
      {
        label: 'shared.title',
        type: 'text',
      },
      {
        label: 'shared.type',
        type: 'text',
        arKey: 'title',
        enKey: 'titleEn',
        hasFilter: true,
        menuData: this.requestTypesList,
      },
      {
        label: 'shared.priority',
        type: 'priorityColors',
        arKey: 'title',
        enKey: 'titleEn',
        hasFilter: true,
        menuData: this.prioritiesList,
      },
      {
        label: 'shared.nextStep',
        type: 'text',
        arKey: 'title',
        enKey: 'titleEn',
        hasFilter: true,
        menuData: this.nextStepsList,
      },
      {
        label: 'shared.incomingFoundation',
        type: 'text',
        arKey: 'title',
        enKey: 'titleEn',
        hasFilter: true,
        menuData: this.foundationsList,
      },
      {
        label: 'shared.studyProposal',
        type: 'proposalEnum',
      },
      {
        label: 'shared.date',
        type: 'dateOnly',
      },
      {
        label: 'shared.consultant',
        type: 'text',
        arKey: 'name',
        enKey: 'name',
        hasFilter: true,
        menuData: this.usersList,
        menuClass: 'lastItemPosition',
      },
      {
        label: 'shared.action',
        type: 'actions',
        actions: [
          {
            action: 'view',
            actionName: 'view',
            onClick: (element: any) => {
              this.View(element);
            },
          },
          {
            action: 'edit',
            actionName: 'edit',
            onClick: (element: any) => {
              this.Edit(element);
            },
          },
        ],
      },
    ];
  }

  onTableFilterChanged(filters: PendingRequestsFiltersForm) {
    if (this.isResetting) return;
    this.allFilters = { ...this.allFilters, ...filters };
    this.loadData();
  }
  appFiltersModel;
  onFiltersComponentChanged(filters: PendingRequestsFiltersForm) {
    this.appFiltersModel = { ...this.allFilters, ...filters };
    const isReset = Object.keys(filters).length === 0;

    if (isReset) {
      this.isResetting = true;
      this.allFilters = {};
      this.pageNumber = this.DEFAULT_PAGE_NUMBER; // Reset to first page
    } else {
      // Normal filter update
      const { searchKeyword, fromDate, toDate, exportTypeId, ...tableFilters } =
        this.allFilters;

      this.allFilters = {
        ...tableFilters,
        ...filters,
      };
    }
    this.loadData();
    if (isReset) {
      setTimeout(() => {
        this.isResetting = false;
      }, 500);
    }
  }

  preparePayload() {
    return {
      pageIndex: this.pageNumber,
      pageSize: this.pageSize,
      ...this.allFilters,
    };
  }
  mapFiltersToApiKeys(filters: any): PendingRequestsFiltersForm {
    return {
      foundationId: filters.foundation || filters.foundationId,
      statusId: filters.status,
      priorityId: filters.priority || filters.priorityId,
      requestTypeId: filters.requestType || filters.requestTypeId,
      consultantId: filters.consultantId || filters.consultant,
      nextStepTitle: filters.nextStep,
      searchKeyword: filters.searchKeyword,
      exportTypeId: filters.proposal,
      fromDate: filters.from,
      toDate: filters.to,
    };
  }
  loadData() {
    this.loadDataSubject.next();
  }
  private performLoadData() {
    const payload = this.preparePayload();
    const { pageIndex, pageSize, ...filtersData } = payload;
    const mappedFilters = this.mapFiltersToApiKeys(filtersData);
    this.isLoading = true;
    this.managePendingTransactionsService.requestsService
      .getPendingRequestsList({ pageIndex, pageSize }, mappedFilters)
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        tap((res) => {
          this.items = res.data;
          this.totalElements = res.totalCount;
        }),
        catchError((err) => {
          this.isError = true;
          return [];
        }),
        finalize(() => {
          this.isLoading = false;
        })
      )
      .subscribe();
  }

  pageChanged(event: any) {
    this.pageNumber = event.pageIndex;
    this.pageSize = event.pageSize;
    this.loadData();
  }
  // onSortChange(e: { key: string; direction: 'asc' | 'desc' }) {
  //   this.sortKey = e.key;
  //   this.sortDirection = e.direction;
  //   this.loadData();
  // }

  onFilter(text: string) {
    this.filterText = text;
    this.pageNumber = 0;
    this.loadData();
  }
  Edit(data: PendingRequest) {
    if (data.isExportDocument) {
      //It is exported document
      this.router.navigate(['imports-exports', data.id, 'export']);
      return;
    }

    //It is imported document
    /*  if (element.status !== RequestStatus.Initiated) {
      this.toastr.error(
        this.translateService.instant(
          'ImportsExportsModule.ImportsExportsListComponent.canotEditImportedDocument'
        )
      );
      return;
    } */

    this.router.navigate(['imports-exports', data.id, 'import']);
  }
  View(data: PendingRequest) {
    let url = `/${RouteConstants.PendingRequest}/${data.id}`;
    this.router.navigateByUrl(url);
  }
}
