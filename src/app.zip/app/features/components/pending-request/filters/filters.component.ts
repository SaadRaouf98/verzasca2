import {
  Component,
  DestroyRef,
  inject,
  Injector,
  OnInit,
  Input,
  ChangeDetectorRef,
  ElementRef,
  Renderer2,
  EventEmitter,
  Output,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { MultiSelectComponent } from '@shared/components/multi-select/multi-select.component';
import { FormControl, FormGroup } from '@angular/forms';
import { ManagePendingTransactionsService } from '@pages/pending-transactions/services/manage-pending-transactions.service';
import { Entity } from '@core/models/entity.model';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { tap, catchError, of, finalize } from 'rxjs';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { InputComponent } from '@shared/components/input/input.component';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FiltersDialogComponent } from '../filters-dialog/filters-dialog.component';
import { SingleSelectComponent } from '@shared/components/single-select/single-select.component';
import { PendingRequestsFiltersForm } from '@core/models/pending-request.model';
import { RequestContainersFiltersForm2 } from '@core/models/transaction.model';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-filters',
  templateUrl: './filters.component.html',
  styleUrls: ['./filters.component.scss'],
  standalone: true,
  imports: [
    SingleSelectComponent,
    ReactiveFormsModule,
    TranslateModule,
    InputComponent,
  ],
})
export class FiltersComponent implements OnInit, OnChanges {
  @Input() prioritiesList: Entity[] = [];
  @Input() nextStepsList: string[] = [];
  @Input() foundationsList: any[] = [];
  @Input() usersList: any[] = [];
  @Input() requestTypesList: any[] = [];
  @Input() isPendingListFilters: boolean = false;
  @Input() selectedPriority;
  @Input() filterData;

  destroyRef = inject(DestroyRef);
  private fb = inject(FormBuilder);
  protected translate = inject(TranslateService);

  private filtersDialogRef: MatDialogRef<FiltersDialogComponent> | null = null;
  private globalClickUnlisten: (() => void) | null = null;
  clicked = false;
  filtersForm!: FormGroup;
  @Output() filtersChange = new EventEmitter<PendingRequestsFiltersForm>();
  @Output() openDialog = new EventEmitter();
  constructor(
    private dialog: MatDialog,
    private renderer: Renderer2,
    private el: ElementRef,
    private changeDetectorRef: ChangeDetectorRef,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.initForm();
  }
  ngOnChanges(changes: SimpleChanges): void {
    // Only update if selectedPriority input actually changed
    if (
      changes['selectedPriority'] &&
      changes['selectedPriority'].currentValue !==
        changes['selectedPriority'].previousValue
    ) {
      if (this.selectedPriority) {
        let isString = this.isString(this.selectedPriority) ? true : false;
        isString
          ? this.filtersForm.controls['priority'].setValue(
              this.selectedPriority
            )
          : this.filtersForm.controls['priority'].setValue(
              this.selectedPriority.id
            );
      } else {
        this.filtersForm?.controls['priority']?.setValue(null);
      }
    }
  }
  isString(variable: any): boolean {
    return typeof variable === 'string';
  }
  initForm() {
    this.filtersForm = this.fb.group({
      priority: [null],
      searchKeyword: [''],
    });

    let searchKey = this.route.snapshot.queryParamMap.get('searchKeyword');
    this.filtersForm.controls['searchKeyword'].setValue(searchKey);
  }
  get hasFormValues(): boolean {
    const formValue = this.filtersForm.value;
    const hasSearchKeyword =
      formValue.searchKeyword && formValue.searchKeyword.trim().length > 0;
    const hasPriority = formValue.priority && formValue.priority !== null;

    return hasSearchKeyword || hasPriority;
  }
  openFiltersDialog(event: MouseEvent) {
    if (this.filtersDialogRef) {
      return;
    }
    this.clicked = true;
    const svgRect = (event.target as HTMLElement).getBoundingClientRect();
    const rem = parseFloat(getComputedStyle(document.documentElement).fontSize);
    const dialogWidth = 23.625 * rem;
    if (!this.isPendingListFilters) {
      this.openDialog.emit(event);
      return;
    }
    let top = svgRect.bottom + window.scrollY;
    let left =
      svgRect.left + window.scrollX + svgRect.width / 2 - dialogWidth / 2;

    this.filtersDialogRef = this.dialog.open(FiltersDialogComponent, {
      height: '558px',
      width: '23.625rem',
      hasBackdrop: false,
      position: {
        top: `${top}px`,
        left: `${left}px`,
      },
      panelClass: 'filters-dialog-panel',
      data: {
        prioritiesList: this.prioritiesList,
        nextStepsList: this.nextStepsList,
        foundationsList: this.foundationsList,
        usersList: this.usersList,
        requestTypesList: this.requestTypesList,
        filterData: this.filterData,
      },
    });

    this.filtersDialogRef.afterOpened().subscribe(() => {
      const dialogComponent = this.filtersDialogRef!.componentInstance;
      dialogComponent.dialogFiltersChange.subscribe(
        (dialogFilters: PendingRequestsFiltersForm) => {
          this.onDialogFiltersChanged(dialogFilters);
        }
      );
      dialogComponent.resetRequested.subscribe(() => {
        this.resetAllFilters();
      });
    });

    setTimeout(() => {
      const dialogContainer = document.querySelector(
        '.mat-mdc-dialog-container'
      ) as HTMLElement;
      if (dialogContainer) {
        const actualWidth = dialogContainer.offsetWidth;
        const actualHeight = dialogContainer.offsetHeight;

        left =
          svgRect.left + window.scrollX + svgRect.width / 2 - actualWidth / 2;
        dialogContainer.style.left = `${left}px`;
        dialogContainer.style.top = `${top}px`;
      }

      // Listen for clicks outside the dialog
      this.globalClickUnlisten = this.renderer.listen(
        'document',
        'mousedown',
        (evt: MouseEvent) => {
          const dialogOverlay = document.querySelector(
            '.cdk-overlay-container'
          );
          const datepickerPopup = document.querySelector(
            '.mat-datepicker-content, .mat-mdc-datepicker-content'
          );
          const trigger = event.target as HTMLElement;

          if (
            (dialogOverlay && dialogOverlay.contains(evt.target as Node)) ||
            (datepickerPopup && datepickerPopup.contains(evt.target as Node)) ||
            trigger.contains(evt.target as Node)
          ) {
            // Do nothing, click is inside dialog, popup, or trigger
            return;
          }

          // Otherwise, close the dialog
          this.filtersDialogRef?.close();
        }
      );
    });

    this.filtersDialogRef.afterClosed().subscribe(() => {
      this.filtersDialogRef = null;
      this.clicked = false;
      this.changeDetectorRef.detectChanges();
      if (this.globalClickUnlisten) {
        this.globalClickUnlisten();
        this.globalClickUnlisten = null;
      }
    });
  }
  resetAllFilters() {
    // Reset the local form
    this.filtersForm.reset({
      priority: null,
      searchKeyword: '',
    });

    // Emit empty filters to trigger reset in parent
    this.filtersChange.emit({} as PendingRequestsFiltersForm);
  }
  emitFiltersChange() {
    const formValue = this.filtersForm.value;
    const cleanedFilters: any = {};

    if (formValue.priority) {
      cleanedFilters.priority = formValue.priority;
    }

    if (formValue.searchKeyword && formValue.searchKeyword.trim()) {
      cleanedFilters.searchKeyword = formValue.searchKeyword.trim();
    }

    this.filtersChange.emit(cleanedFilters as PendingRequestsFiltersForm);
  }
  onDialogFiltersChanged(dialogFilters: PendingRequestsFiltersForm) {
    const mergedFilters = { ...this.filtersForm.value, ...dialogFilters };
    this.filtersChange.emit(mergedFilters);
  }
  ngOnDestroy(): void {
    if (this.globalClickUnlisten) {
      this.globalClickUnlisten();
    }
  }
}
