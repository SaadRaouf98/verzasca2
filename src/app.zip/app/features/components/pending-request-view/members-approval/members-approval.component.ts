import { Component, Inject, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { MemberApprovalType } from '@core/enums/member-approval-type.enum';
import {
  MAT_DIALOG_DATA,
  MatDialogRef,
  MatDialog,
} from '@angular/material/dialog';
import { CommitteeApproval } from '@core/models/request.model';
import { TakeCommitteeMemberApprovalActionComponent } from '@pages/imports-exports/modals/take-committee-member-approval-action/take-committee-member-approval-action.component';
import { ViewCommitteeMembersApprovalComponent } from '@pages/imports-exports/modals/view-committee-members-approval/view-committee-members-approval.component';
import { ManageImportsExportsService } from '@pages/imports-exports/services/manage-imports-exports.service';
import { ViewNoteModalComponent } from '@pages/manage-records/components/view-note-modal/view-note-modal.component';
import { ModalStatusCode } from '@shared/enums/modal-status-code.enum';
import { isSmallDeviceWidthForPopup } from '@shared/helpers/helpers';
import { ToastrService } from 'ngx-toastr';
import { Clipboard } from '@angular/cdk/clipboard';
import { NgxPermissionsModule } from 'ngx-permissions';
import { PermissionsObj } from '@core/constants/permissions.constant';

@Component({
  selector: 'app-members-approval',
  standalone: true,
  imports: [CommonModule, NgxPermissionsModule, TranslateModule],
  templateUrl: './members-approval.component.html',
  styleUrls: ['./members-approval.component.scss'],
})
export class MembersApprovalComponent {
  PermissionsObj = PermissionsObj;
  @Input() isCommitteeApprovalStep!: boolean;
  @Input() committeeMembersApprovals: any[] = [];
  @Input() requestId!: string;
  MemberApprovalType = MemberApprovalType;

  constructor(
    private clipboard: Clipboard,
    private dialog: MatDialog,
    private toastr: ToastrService
  ) {}

  onTakeActionViaPhone(committeeApproval: CommitteeApproval): void {
    this.dialog.open(TakeCommitteeMemberApprovalActionComponent, {
      minWidth: '31.25rem',
      maxWidth: '31.25rem',
      maxHeight: '44.3125rem',
      panelClass: 'action-modal',
      autoFocus: false,
      disableClose: true,
      data: {
        requestId: this.requestId,
        committeeApproval: committeeApproval,
      },
    });
  }
}
